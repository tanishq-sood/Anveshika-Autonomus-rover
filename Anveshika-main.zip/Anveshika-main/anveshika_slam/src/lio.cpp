#include "anveshika_slam/lio.hpp"

namespace anveshika_slam
{

LIONode::LIONode(const rclcpp::NodeOptions &options)
: Node("lio_node", options)
{

}

LIONode::~LIONode()
{

}

} // namespace anveshika_slam