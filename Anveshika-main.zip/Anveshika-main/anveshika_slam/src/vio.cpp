#include "anveshika_slam/vio.hpp"

namespace anveshika_slam
{

VIONode::VIONode(const rclcpp::NodeOptions &options)
: Node("vio_node", options)
{

}

VIONode::~VIONode()
{

}

} // namespace anveshika_slam