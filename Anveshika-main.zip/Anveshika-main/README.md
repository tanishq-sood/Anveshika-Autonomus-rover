# Anveshika

A 4-wheeled rover with a robotic arm for autonomous exploration and manipulation tasks.

## Status
Currently under refactoring

## Features
- 4-wheel drive system
- Robotic arm for manipulation
- Autonomous navigation capabilities